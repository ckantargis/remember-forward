REMEMBER FORWARD — THE PATIENT MESSAGE
Complete Archive · CC BY-SA 4.0 · rememberforward.org
=======================================================

WHAT'S IN THIS ARCHIVE

  plates/               All 219 SVG plates + print-ready PDF
    knowledge/          11 knowledge plates (survival to metaphysics)
    languages/          49 language series, 4 plates each

  guides/               Build and context guides
    gd_00  Main guide — how to use this system
    gd_01  IP manufacturing — making the plates
    gd_02  Founder's letter — why this exists
    gd_03  Tier 1 — Survival knowledge
    gd_04  Tier 2 — Agriculture
    gd_05  Tier 3 — Technology re-foundation
    gd_06  Tier 4 — Governance and ethics
    gd_07  Tier 5 — Advanced science
    gd_08  Tier 6 — Metaphysics and meaning

  containers/           Container design and burial guides
    Tier 0   Fired ceramic + pitch ($10-30 · 500-2000 yrs)
    Tier A   Schedule 80 PVC ($75-150 · 100-300 yrs)
    Tier B   Titanium tube ($300-600 · 1000-5000 yrs)
    Tier C   Ocean deployment
    Tier D   Network distribution
    Tier E   Hastelloy alloy ($2000+ · 5000+ yrs)
    Tier F   Granite vault ($10,000+ · indefinite)
    Location strategies guide

  project/              Project documentation
    master_handoff.docx
    inner_ark_operational_structure.docx

THE BRIDGE PHRASE
"This was made for you, freely, by people who remembered forward."
Engraved on every Plate D in every language.

LICENSE
  CC BY-SA 4.0 — copy, adapt, distribute freely.
  The knowledge belongs to whoever finds it.
  https://creativecommons.org/licenses/by-sa/4.0/

rememberforward.org
