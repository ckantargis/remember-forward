REMEMBER FORWARD — THE PATIENT MESSAGE
CC BY-SA 4.0 · rememberforward.org
========================================

This archive contains 245 SVG plate files.

STRUCTURE
  plates/knowledge/       11 knowledge plates (survival -> metaphysics)
  plates/languages/{lang} 4 plates per language (60 languages)

PLATE TYPES (per language)
  A = Script & writing system
  B = Phonology
  C = Grammar & vocabulary
  D = Running text & bridge phrase

BRIDGE PHRASE (on every Plate D)
"This was made for you, freely, by people who remembered forward."

FORMAT
  SVG · 480×680px · black strokes only · laser-engraver ready
  Designed for nickel or stainless steel plate engraving

LICENSE
  Creative Commons Attribution-ShareAlike 4.0 International
  Copy · Translate · Improve · Distribute freely
