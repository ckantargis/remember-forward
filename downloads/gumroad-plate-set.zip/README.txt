REMEMBER FORWARD — THE PATIENT MESSAGE
Plate Set · CC BY-SA 4.0 · rememberforward.org
================================================

WHAT'S IN THIS ARCHIVE
  plates/knowledge/       11 knowledge plates
  plates/languages/       49 language series, 4 plates each (208 plates)
  remember-forward-plates.pdf   All plates as a single print-ready PDF

PLATE TYPES (each language)
  A  Script & writing system — alphabet, syllabary, or abugida
  B  Phonology — sound inventory, tones, vowel systems, IPA
  C  Grammar & vocabulary — word order, verb system, ~30 core words
  D  Running text & bridge phrase — real passages with interlinear gloss

THE BRIDGE PHRASE
Every Plate D ends with this phrase in the target language:
"This was made for you, freely, by people who remembered forward."

LANGUAGES COVERED
  Hebrew (Biblical · Mishnaic · Yemenite · Modern), Arabic, Tamil, Sanskrit,
  Bengali, Mandarin, Japanese, Malay/Indonesian, Swahili, Greek, Latin,
  Persian, Russian, Hindi, Spanish, Portuguese, French, Hausa, Yoruba,
  Amharic, Somali, Lingala, Tigrinya, Igbo, Shona, Zulu, Vietnamese, Thai,
  Burmese, Lao, Tagalog, Javanese, Sinhala, Tok Pisin, Quechua, Nahuatl,
  English, Dutch, Korean, Turkish, German, Punjabi, Urdu, Pashto, Tibetan,
  Mongolian, Khmer, Hawaiian, Egyptian Arabic

FORMAT
  SVG · 480x680 pt · black strokes only · no fills · no color
  Laser-engraver ready · scales to any material size
  Recommended material: nickel, stainless steel, or anodized aluminum

PRINTING
  The included PDF prints at 5"x7" on standard paper.
  For metal engraving, open SVGs in LightBurn, RDWorks, or Inkscape.

LICENSE
  CC BY-SA 4.0 — copy, adapt, distribute, even commercially,
  as long as you credit and share alike.
  https://creativecommons.org/licenses/by-sa/4.0/

SUPPORT
  If this was useful, consider buying a copy for someone else.
  rememberforward.org
